<?php

return [
    'en_US' => 'English',
    'es_ES' => 'Español',
    'es_AR' => 'Español Argentina',
    'it_IT' => 'Italiano',
    'fr_FR' => 'Français',
    'ru_RU' => 'Russian',
    'hy_AM' => 'Armenian',
];
