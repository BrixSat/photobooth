<div class="row">
    <div class="form-group col-md-4 col-md-offset-4">
        <div class="form-group has-feedback">
            <label for="email">{{ trans('user.appointments.form.email.label') }}</label>
            <input type="email" name="email" class="form-control" placeholder="{{ trans('user.appointments.form.email.label') }}" required>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        </div>
    </div>
</div>