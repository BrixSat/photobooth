<a href="{{ $link }}" title="{{ trans($title) }}">
    <div class="info-box">
    <span class="info-box-icon bg-{{ $color }}"><i class="fa fa-{{ $icon }}"></i></span>
    <div class="info-box-content">
      <span class="info-box-text">{{ trans($title) }}</span>
      <span class="info-box-number">{{ $number }}</span>
    </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
</a>