<?php

return  [
  'manager' => [
    'appointments' => [
      'title' => 'Tu agenda está vacía',
      'hint'  => 'Compartí tu página de timegrid con tus clientes para empezar a tomar reservas.',
    ],
  ],
];
