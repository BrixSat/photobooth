<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/07/20 17:32:03
*************************************************************************/

return [
  'alert'    => '¡Muy bien! Contanos qué te gustaría hacer',
  'business' => [
    'btn'     => 'Quiero otorgar turnos',
    'header'  => 'Soy prestador',
    'caption' => '¿Tenés un comercio y querés dar citas? Registrá tu local y empezá a dar citas hoy mismo.',
  ],
  'user' => [
    'btn'     => 'Quiero pedir turnos',
    'header'  => 'Soy cliente',
    'caption' => '¿Tu prestador te dijo que solicites un turno por Internet? Es acá.',
  ],
];
