<?php

return  [

  'btn' => [
    'edit'   => 'Edit Service Types',
    'update' => 'Update',
  ],

  'title' => [
    'edit' => 'Edit Service Types',
  ],

  'msg' => [
    'update' => [
        'success' => 'Service types were updated!',
    ],
  ],

];
