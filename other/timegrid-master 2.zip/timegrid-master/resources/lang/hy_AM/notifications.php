<?php

return [
  'user' => [
    'checkingVacancies'          => ':Օգտատերը ստուգել է Ձեր աշխատանքային ժամերը',
    'booked'                     => ':Օգտատերը կատարել  է  գրանցում  :businessName -ում' ,
    'visitedShowroom'            => ':Օգտատերը հետաքրքրված է :businessName -ով',
    'subscribedBusiness'         => ':Օգտատերը բաժանորդագրվել է :businessName -ին',
    'registeredBusiness'         => ':Օգտատերը գրանցվել է  :businessName -ում!',
    'updatedBusinessPreferences' => ':Օգտատերը փոխել է :businessName -ի նախընտրությունները',
  ],
  'appointment' => [
    'reserve'  => ':Օգտատերը կատարել  է  գրանցում :code of date :date',
    'cancel'   => ':Հաճախորդը չեղարկել է գրանցումը :code of date :date',
    'confirm'  => ':Հաճախորդը հաստատել է իր գրանցումը :code of date :date',
    'serve'    => ':Հաճախորդը սպասարկվել է :code of date :date',
    ],
];
