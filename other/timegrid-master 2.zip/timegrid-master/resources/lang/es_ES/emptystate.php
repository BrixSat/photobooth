<?php

return  [
  'manager' => [
    'appointments' => [
      'title' => 'Tu agenda está vacía',
      'hint'  => 'Comparte tu página de timegrid con tus clientes para comenzar a tomar reservas.',
    ],
  ],
];
