<?php

return  [
  //============================== New strings to translate ==============================//
  'manager' =>  [
    'left' =>  [
      'dashboard'     => 'Tablero',
      'notifications' => 'Notificaciones',
      'preferences'   => 'Preferencias',
      'edit'          => 'Editar',
      'addressbook'   => 'Contactos',
      'agenda'        => 'Turnos',
      'availability'  => 'Disponibilidad',
      'calendar'      => 'Agenda',
      'services'      => 'Servicios',
      'staff'         => 'Staff',
    ],
  ],
];
