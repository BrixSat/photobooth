<?php

return  [
  //============================== New strings to translate ==============================//
  'manager' =>  [
    'left' =>  [
      'dashboard'     => 'Панель',
      'notifications' => 'Уведомления',
      'preferences'   => 'Настройки',
      'edit'          => 'Редактировать',
      'addressbook'   => 'Адресная книга',
      'agenda'        => 'График',
      'availability'  => 'Доступность',
      'calendar'      => 'Календарь',
      'services'      => 'Сервисы',
      'staff'         => 'Специалисты',
    ],
  ],
];
