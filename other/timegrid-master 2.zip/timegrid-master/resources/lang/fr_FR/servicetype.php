<?php

return  [

  'btn' => [
    'edit'   => 'Modifier les types de Service',
    'update' => 'Modifier',
  ],

  'title' => [
    'edit' => 'Modifier les types de service',
  ],

  'msg' => [
    'update' => [
        'success' => 'Les types de service ont été mis à jour!',
    ],
  ],

];
