<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/07/20 17:32:03
*************************************************************************/

return [
  'alert'    => 'Bien joué! Veuillez nous dire quels sont vos projets',
  'business' => [
    'btn'     => 'Je souhaite offrir des services',
    'header'  => 'Je dirige une entreprise',
    'caption' => 'Avez-vous besoin de rendez-vous en ligne pour vos services? Enregistrez votre entreprise et commencez à prendre des rendez-vous dès aujourd\'hui.',
  ],
  'user' => [
    'btn'     => 'Je veux faire des réservations',
    'header'  => 'Je suis un client',
    'caption' => 'Avez-vous besoin de faire une réservation pour un service?',
  ],
];
