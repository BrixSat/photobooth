<?php

namespace App\Exceptions;

class BusinessAlreadyRegistered extends \Exception
{
}
