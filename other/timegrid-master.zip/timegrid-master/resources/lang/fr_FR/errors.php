<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/08/10 14:35:44
*************************************************************************/

return [
  403 => [
    'description' => '403 Non autorisé',
  ],
  404 => [
    'description' => '404 Introuvable',
  ],
];
