<?php

return  [
  //============================== New strings to translate ==============================//
  'manager' =>  [
    'left' =>  [
      'dashboard'     => 'Կառավարման վահանակ',
      'notifications' => 'Ծանուցումներ',
      'preferences'   => 'Նախընտրություններ',
      'edit'          => 'Խմբագրել',
      'addressbook'   => 'Հաճախորդներ',
      'agenda'        => 'Գրանցումներ',
      'availability'  => 'Աշխատանքային ժամեր',
      'calendar'      => 'Օրացույց',
      'services'      => 'Ծառայություններ',
      'staff'         => 'Մասնագետներ',
    ],
  ],
];
