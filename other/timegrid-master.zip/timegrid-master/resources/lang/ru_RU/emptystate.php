<?php

return  [
  'manager' => [
    'appointments' => [
      'title' => 'Ваш график пуст',
      'hint'  => 'Начните принимать заказы',
    ],
  ],
];
