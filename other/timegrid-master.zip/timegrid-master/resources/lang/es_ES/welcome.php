<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/12/09 15:37:10
*************************************************************************/

return [
  'feature' => [
    1 => [
      'content' => 'Asigna las citas por tí para que puedas dedicarte a lo que importa. Tu tiempo vale.',
      'title'   => 'Optimiza',
    ],
    2 => [
      'content' => 'Mantiene a todos tus contactos organizados para que tu cartera de clientes esté siempre vigente.',
      'title'   => 'Fideliza',
    ],
    3 => [
      'content' => 'Le da a tus clientes el servicio que merecen, porque realmente lo merecen.',
      'title'   => 'Profesionaliza',
    ],
    4 => [
      'content' => 'Es hora de aprovechar el tiempo ahorrado y tomar unas buenas vacaciones.',
      'title'   => 'Libera',
    ],
  ],
  'jumbotron' => [
    'btn' => [
      'begin' => 'Empecemos',
      'login' => 'Iniciar Sesión',
    ],
    'description' => 'La agenda de citas para profesionales exitosos.',
    'title'       => 'timegrid.io',
  ],
];
