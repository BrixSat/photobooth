<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/12/09 15:37:10
*************************************************************************/

return [
  'feature' => [
    1 => [
      'content' => 'Dai la possibilit&agrave; ai tuoi clienti di scegliere quando prenotare.',
      'title'   => 'Ottimizza',
    ],
    2 => [
      'content' => 'Aggrega i tuoi contatti e ottieni nuovi clienti.',
      'title'   => 'Rateizza',
    ],
    3 => [
      'content' => 'Fornisci un servizio migliore ai tuoi clienti.',
      'title'   => 'Professionalizza',
    ],
    4 => [
      'content' => 'E\'ora di risparmiare tempo e goderti le tue vacanze.',
      'title'   => 'Liberati',
    ],
  ],
  'jumbotron' => [
    'btn' => [
      'begin' => 'Iniziamo',
      'login' => 'Login',
    ],
    'description' => 'L\'app di prenotazione per i professionisti di successo.',
    'title'       => 'timegrid.io',
  ],
];
