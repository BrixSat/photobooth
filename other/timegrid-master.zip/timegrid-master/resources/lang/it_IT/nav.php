<?php

return  [
  //==================================== Translations ====================================//
  'manager' => [
    'left' => [
      'addressbook'   => 'Rubrica',
      'agenda'        => 'Agenda',
      'availability'  => 'Disponibilit&agrave;',
      'calendar'      => 'Calendario',
      'dashboard'     => 'Dashboard',
      'edit'          => 'Modifica',
      'notifications' => 'Notifiche',
      'preferences'   => 'Impostazioni',
      'services'      => 'Servizi',
      'staff'         => 'Staff',
    ],
  ],
];
