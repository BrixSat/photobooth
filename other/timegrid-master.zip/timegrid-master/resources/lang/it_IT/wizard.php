<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/07/20 17:32:03
*************************************************************************/

return [
  'alert'    => 'Bene! Per favore dicci cosa ti piacerebbe fare',
  'business' => [
    'btn'     => 'Voglio fornire servizi',
    'header'  => 'Ho un\'azienda',
    'caption' => 'Hai bisogno di fornire appuntamenti online per i tuoi servizi? Registra la tua azienda ed inizia a fornire appuntamenti oggi stesso.',
  ],
  'user' => [
    'btn'     => 'Voglio prendere un appuntamento',
    'header'  => 'Sono un cliente',
    'caption' => 'Hai bisogno di prendere un appuntamento per un servizio?',
  ],
];
